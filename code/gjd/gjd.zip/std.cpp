#include<bits/stdc++.h>
using namespace std;

int main(){	
	freopen("gjd.in","r",stdin);
	freopen("std.out","w",stdout);
	long long a,b;
	cin>>a>>b;	
	cout<<a+b<<endl;
	cout<<a-b<<endl;
	cout<<a*b<<endl;
	cout<<a/b<<endl;
	cout<<a%b<<endl;
	return 0;
}
	
