#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
const int N = 1005;
struct bign{
	int len,data[N];
	bign(){
		len = 1;
		memset(data,0,sizeof(data));
	}
	bign(int x){
		memset(data,0,sizeof(data));
		for (len = 0;x>0;x/=10)
			data[len++] = x%10;
		if (len==0) len = 1;
	}
	bign(const char *s){
		memset(data,0,sizeof(data));
		len = strlen(s);
		for (int i=0;i<len;i++)
			data[i] = s[len-1-i]-'0';
	}
	bign(const string &s){
		memset(data,0,sizeof(data));
		len = s.size();
		for (int i=0;i<len;i++)
			data[i] = s[len-1-i]-'0';
	}
	bign operator = (int x){
		memset(data,0,sizeof(data));
		for (len = 0;x>0;x/=10)
			data[len++] = x%10;
		if (len==0) len = 1;
		return *this;
	}
	bign operator = (const char *s){
		memset(data,0,sizeof(data));
		len = strlen(s);
		for (int i=0;i<len;i++)
			data[i] = s[len-1-i]-'0';
		return *this;
	}
	bign operator = (const string &s){
		memset(data,0,sizeof(data));
		len = s.size();
		for (int i=0;i<len;i++)
			data[i] = s[len-1-i]-'0';
		return *this;
	}
	bool operator < (const bign &x)const{
		if (len != x.len) return len < x.len ;
		for (int i=len-1;i>=0;i--)
			if (data[i] != x.data[i])
				return data[i] < x.data[i];
		return false;
	}
	bool operator > (const bign &x){
		return x < *this; 
	}
	bool operator <= (const bign &x){
		return ! (x < *this); 
	}
	bool operator >= (const bign &x){
		return !(*this < x); 
	}
	bool operator == (const bign &x){
		return !(*this<x) && !(x < *this); 
	}	
	bool operator != (const bign &x){
		return *this < x || x < *this; 
	}	
	bign operator +(const bign &b){
		bign r;
		r.len =  max(len,b.len);
		for (int i=0;i<r.len;i++){
			r.data[i] += data[i] + b.data[i];
			r.data[i+1] = r.data[i]/10;
			r.data[i] %= 10;
		}
		if (r.data[r.len]) r.len++;
		return r;
	}
	string str(){
		string r;
		for (int i=len-1;i>=0;i--)
			r += (char)(data[i]+'0');
		return r;
	}
	friend istream& operator >>(istream& input,bign &x){
		string s;
		input >> s;
		x = s;
		return input;
	}
	friend ostream& operator <<(ostream& output,bign x){
		output << x.str() ;
		return output;
	}
};
	
int main(){
	string s("456789");
	bign a("956"),b("999");
	while (cin>>a>>b)
		cout<<a+b<<endl;
	return 0;	
}
