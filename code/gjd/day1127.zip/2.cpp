#include<iostream>
#include<algorithm>
using namespace std;
struct stu{
	string name;
	double chi,mat,eng,tot;
	stu(){ tot = 0;	}
	stu(string xm,double yw,double sx,double yy):name(xm),chi(yw),mat(sx),eng(yy){
//		name = xm;
//		chi = yw;
//		mat = sx;
//		eng = yy;
		tot = yw+sx+yy;
	}
	bool operator < (const stu &x)const{
		if (tot < x.tot ) return true;
		else return false;
	}
};
stu a[10000];
int main(){
	stu y,x("Fan Ruxi",110,150,140);
	cout<<x.name <<" "<<x.tot <<endl;
	
	int n;
	cin>>n;
	

	for (int i=0;i<n;i++){
		cin>>a[i].name >>a[i].chi>>a[i].mat>>a[i].eng;
		a[i].tot  = a[i].chi+a[i].mat+a[i].eng;
	}
	sort(a,a+n);
	for (int i=0;i<n;i++)
		cout<<a[i].name <<" "
			<<a[i].chi <<" "
			<<a[i].mat <<" "
			<<a[i].eng <<" "
			<<a[i].tot <<endl;
	return 0;					
}
